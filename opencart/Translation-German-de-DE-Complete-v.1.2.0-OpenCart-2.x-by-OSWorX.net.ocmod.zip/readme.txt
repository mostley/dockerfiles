$Id: readme.txt 4343 2016-06-01 10:18:23Z mic $

readme German Translation (de-DE) for OpenCart
==============================================

Package/Paket	Languages (admin/user) - Sprachen (Admin/Benutzer)
Requirement		OpenCart 2.x
Copyright		https://osworx.net
License			GNU/GPL http://www.gnu.org/copyleft/gpl.html
-----------------------------------------------------------------

English
=======

Description
***********
Complete German Translation for admin (Backend) and user (Frontend / shop)

Installation (and Update)
*************************

Method 1 (and to use German during the installation process)
------------------------------------------------------------

To install this language package, extract the zipped package locally
and transfer the files (same structure as you can see) with FTP
to your server (current shop installation).

Method 2 (shop is already installed or to update existing language files)
------------------------------------

To install this language package, navigate in the backend to Extensions > Installer,
select this package and follow th onscreen instructions.

General (after a new installation)
----------------------------------

After that, open your OpenCart backend and follow these steps:

1. Menu > System -> Localisation -> Languages
2. Click the Edit button
3. Fill in the following values:

	3.1 Language	Deutsch (German)
	3.2 Code		de
	3.3 Locale		de,de-DE,de_DE,de_DE.UTF-8,de-de,de-AT,de-CH,german
	3.4 Image		de.png
	3.5 Directory	de-DE
	3.6 Status		Enabled
	3.7 Sort Order	1

    Save

4. Menu > System -> Settings
5. Click on the tab Locale and define your standard languages for
    front- and backend (backend language will not change BEFORE this step!)
6. Save
7. Ready

Deutsch
=======

Beschreibung
************
Komplette deutsche Übersetzung für Admin (Backend) und Benutzer (Frontend / Shop)
inklusive Installationssprache

Installation (und Update)
*************************

Methode 1 (Shop ist noch nicht installiert und Deutsch soll während der Installation verwendet werden)
------------------------------------------------------------------------------------------------------

Um dieses Sprachenpaket zu installieren, das gezippte Paket lokal entpacken.
Anschließend die Dateien (gleiche Verzeichnisstruktur wie sichtbar
im Ordner upload) per FTP auf den Server (Shopinstallation) kopieren.

Methode 2 (Shop ist bereits installiert oder vorhandene Sprachdateien akualisieren)
-----------------------------------------------------------------------------------

Im Shopbackend über das Menü Erweiterungen > Installer
dieses Paket auswählen und den Anweisungen am Bildschirm folgen

Generell (umstellen auf Deutsch bei Neuinstallation)
----------------------------------------------------

Hinweis: das System zeigt bei einer Neuinstallation noch die englische Sprache an,
daher sind im Folgenden etliche Begriffe in Englisch (wie im Shop angezeigt) angegeben:

1.	Backend aufrufen Menü > System -> Localisation -> Languages
2.	Button "Insert" anklicken
3.	Folgende Werte eingeben:

	3.1 Language	Deutsch (German)
	3.2 Code		de
	3.3 Locale		de-DE,de_DE,de-de,de_DE.UTF-8,german (nur OpenCart < 2.2.x )
	3.4 Image		de.png (nur OpenCart < 2.2.x )
	3.5 Directory	de-DE (nur OpenCart < 2.2.x )
	3.6 Status		Enabled
	3.7 Sort Order	1

    Sichern (Button Save rechts oben anklicken)

4.	Menü > System -> Settings aufrufen
5.	Reiter "Locale" anklicken und die Standardsprache für Admin und Benutzer
	festlegen > erst dann schaltet das Backend auf die hier eingestellte Sprache
    um!
6.	Speichern (Button Sichern rechts oben anklicken)
7.	Fertig

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WICHTIG !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Um den verschiedenen Gesetzen zu entprechen (speziell EU-Raum, AT, DE),         !
! kann es erforderlich sein, dass verschiedene Variablen (z.B. $_['text_price'] ) !
! angepasst werden müssen!                                                        !
! Näheres dazu auf https://osworx.net wo wir ein spezielles Paket zur Verfügung   !
! stellen, mit welchem die rechtlichen Anforderungen abgedeckt werden.            !
!                                                                                 !
! Siehe dazu Module LEGAL sowie EUCookie auf https://osworx.net                   !
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WICHTIG !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Installationssprache
********************
In diesem Paket ist auch die dt. Sprache für eine Installation in Deutsch enthalten.
Wird das Sprachpaket VOR der ERSTINSTALLATION auf den Server kopiert, kann die
Installation in Deutsch erfolgen.

Support
*******
https://osworx.net

Guarantee & Warranty
********************
This extension is created under best effort.
Unlikely we cannot guarantee for any lost of data or malfunction.

License
*******
Notes:
    > this package can be used for own works / derivates to following conditions:
    - headers:
		- must stay intact
        - you are allowed to add your own lines
        - you are NOT allowed to delete any line of the headers
    - this readme has always to be included in further packages
    - building own commercial packages with this as base is strictly forbidden!

Hinweise:
    > dieses Paket kann für eigene Werke zu folgenden Konditionen verwendet werden:
    - Kopfzeilen:
		- müssen intakt bleiben
        - es können eigene Zeilen hinzugefügt werden
        - es dürfen KEINE Kopfzeilen sowie Copyrightinformationen gelöscht werden
    - diese Datei (readme.txt) muss in allen zukünftigen Paketen inkludiert sein
    - eigene kommerzielle Pakete damit zu erstellen ist strikt verboten (siehe Lizenz)!

Versionen/Changelog (rev)
*************************
legend
* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note
-------------------------
1.2.0	2016.01.01	+ OC 2.2.x. vars
					+ missing var (reward)
					^ minor rewording
1.1.1	2016.02.09	^ minor rewording
					^ language package as ocmod installer
1.0.20	2016.02.02	^ rewording activities
1.0.19	2016.01.30	+ new vars
1.0.18	2016.01.18	^ minor rewording
1.0.17	2016.01.05	^ minor rewording
					# typo
1.0.16	2016.01.05	# file encoding
					^ minor rewording
1.0.15	2015.12.02	^ admin - installer > links removed
1.0.14	2015.10.20	^ minor rewording, admin date changed
					# recaptcha, file encoding UTF-8
1.0.13	2015.10.15	^ typos, rewording, file encoding
1.0.12	2015.10.07	+ OC 2.1.x values
1.0.11	2015.09.05	# typo payment paypal_standard
					+ paypal_standard colored states
					+ new var (general)
1.0.10	2015.08.23	# typo, wording
1.0.9	2015.04.06	# typos
					+ OC 2.0.2.0 vars
					+ missing payment images
					+ jquery.jqvmap localized German map
					^ reworked install file
					^ renamed default.php to LANGUAGE_NAME.php (changed 2.0.2.0 again!)
1.0.8	2015.03.28	# default.php (UTF-8)
					# typos
1.0.7	2015.03.02	+ new vars (OC v.2.0.1.1)
					# typos
1.0.6	2014.10.02	+ new vars (backend)
1.0.5	2014.10.02	^ minor rewording
1.0.4	2014.10.01	^ final stable release 2.0.0.0 vars
1.0.3	2014.09.28	+ files and vars as of beta 4
1.0.2	2014.08.18	+ new vars
					- old vars
					# typos
1.0.1	2014.06.10	+ new vars
					- old vars
					- double vars
					# typos
1.0.0	2014.06.06	initial release