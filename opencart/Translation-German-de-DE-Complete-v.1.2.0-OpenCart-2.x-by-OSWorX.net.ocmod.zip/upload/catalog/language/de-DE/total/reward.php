<?php
/**
 * @version		$Id: reward.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2013 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Mit Bonuspunkten bezahlen (aktueller Punktestand %s)';

// Text
$_['text_reward']	= 'Bonuspunkte (%s)';
$_['text_order_id']	= 'Auftragsnr. %s';
$_['text_success']	= 'Bonuspunkte erfolgreich angewendet';

// Entry
$_['entry_reward']	= 'Max. anzuwendende Punkte: %s';

// Error
$_['error_reward']	= 'Bitte Punkteanzahl angeben';
$_['error_points']	= 'Hinweis: es stehen keine %s Punkte zur Verfügung';
$_['error_maximum']	= 'Es können nur maximal %s Punkte angewendet werden';