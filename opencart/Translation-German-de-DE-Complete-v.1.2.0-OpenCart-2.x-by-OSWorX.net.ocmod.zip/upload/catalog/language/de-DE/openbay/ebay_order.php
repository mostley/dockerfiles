<?php
/**
 * @version		$Id: ebay_order.php 4163 2015-12-10 18:05:49Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_total_shipping']		= 'Versand';
$_['text_total_discount']		= 'Nachlass';
$_['text_total_tax']			= 'Steuer';
$_['text_total_sub']			= 'Zwischensumme';
$_['text_total']				= 'Gesamt';
$_['text_smp_id']				= 'Verkäufernr.: ';
$_['text_buyer']				= 'Käufername: ';