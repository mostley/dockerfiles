<?php
/**
 * @version		$Id: amazonus_order.php 3755 2014-10-02 08:55:51Z mic $
 * @package		Translation - Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_paid_amazon'] 			= 'Bezahlt bei Amazon US';
$_['text_total_shipping'] 		= 'Versand';
$_['text_total_shipping_tax'] 	= 'Steuern Versand';
$_['text_total_giftwrap'] 		= 'Geschenk';
$_['text_total_giftwrap_tax'] 	= 'Steuern Geschenk';
$_['text_total_sub'] 			= 'Zwischensumme';
$_['text_tax'] 					= 'Steuer';
$_['text_total'] 				= 'Gesamt';