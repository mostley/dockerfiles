<?php
/**
 * @version		$Id: basic_captcha.php 4075 2015-10-07 14:46:38Z mic $
 * @package		Language German - Backend
 * @author		mic - http://osworx.net
 * @copyright	2015 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Captcha';

// Entry
$_['entry_captcha']	= 'Bitte Code in der Box angeben';

// Error
$_['error_captcha']	= 'Angegebener Code stimmt nicht mit angezeigtem überein!';