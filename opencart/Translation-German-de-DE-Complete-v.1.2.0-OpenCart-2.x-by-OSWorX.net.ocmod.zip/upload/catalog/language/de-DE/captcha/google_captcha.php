<?php
/**
 * @version		$Id: google_captcha.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Language German - Backend
 * @author		mic - http://osworx.net
 * @copyright	2015 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title'] = 'Captcha';

// Entry
$_['entry_captcha']	= 'Bitte nachstehende Aufgabe ausführen';

// Error
$_['error_captcha']	= 'Angegebener Code bzw. Lösung ist nicht richtig';