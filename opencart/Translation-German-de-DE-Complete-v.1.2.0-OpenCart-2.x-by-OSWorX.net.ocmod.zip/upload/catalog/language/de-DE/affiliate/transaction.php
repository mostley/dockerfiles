<?php
/**
 * @version		$Id: transaction.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Deutsch Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']			= 'Meine Transaktionen';

// Column
$_['column_date_added']		= 'Erstellt';
$_['column_description']	= 'Beschreibung';
$_['column_amount']			= 'Betrag (%s)';

// Text
$_['text_account']			= 'Konto';
$_['text_transaction']		= 'Transaktionen';
$_['text_balance']			= 'Aktueller Saldo';
$_['text_empty']			= 'Noch keine Transaktionen vorhanden';