<?php
/**
 * @version		$Id: forgotten.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_subject']	= '%s - Neues Passwort';
$_['text_greeting']	= 'Von %s wurde ein neues Passwort angefordert.';
$_['text_change']	= 'Um das Passwort zur�ck zu setzen, bitte nachstehenden Link anklicken:';
$_['text_ip']		= 'Die IP-Adresse von welcher diese Anforderung abgesetzt wurde lautet: %s';

	// OC < 2.2
$_['text_password']	= 'Das neue Passwort lautet:';