<?php
/**
 * @version		$Id: g2apay.php 4037 2015-08-23 15:49:05Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2015 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title'] = 'Bezahlen mit G2APay';