<?php
/**
 * @version		$Id: pp_standard.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Hinweis!!! Diese Zahlungsart befindet sich momentan im <b>Testmodus</b> - es werden keine realen Zahlungen durchgeführt.';
$_['text_total']	= 'Versand, Steuern &amp; weitere Gebühren';
	// OC < 2.2
$_['text_reason']	= 'Grund';