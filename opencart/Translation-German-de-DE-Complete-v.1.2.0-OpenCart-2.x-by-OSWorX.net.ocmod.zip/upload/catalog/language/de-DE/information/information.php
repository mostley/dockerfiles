<?php
/**
 * @version		$Id: information.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_error']	= 'Leider konnte die gesuchte Seite nicht gefunden werden - eventuell ein Tippfehler oder veralteter Link?';