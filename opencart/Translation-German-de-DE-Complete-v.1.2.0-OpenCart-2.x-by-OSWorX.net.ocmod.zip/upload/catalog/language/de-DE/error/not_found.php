<?php
/**
 * @version		$Id: not_found.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Seite nicht gefunden';

// Text
$_['text_error']	= 'Trotz aller Anstrengungen kann die angeforderte Seite leider nicht gefunden werden.<br />Sollte das Problem weiterhin bestehen bitte uns kontaktieren - vielen Dank.';