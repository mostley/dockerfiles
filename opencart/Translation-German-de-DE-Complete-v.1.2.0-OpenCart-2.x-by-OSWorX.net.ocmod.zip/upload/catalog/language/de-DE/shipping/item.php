<?php
/**
 * @version		$Id: item.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']		= 'Versandkosten pro Stück';
$_['text_description']	= 'Versandkosten pro Stück';