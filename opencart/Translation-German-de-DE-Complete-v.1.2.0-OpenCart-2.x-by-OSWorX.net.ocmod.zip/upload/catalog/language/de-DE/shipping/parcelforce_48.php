<?php
/**
 * @version		$Id: parcelforce_48.php 3721 2014-08-18 13:37:29Z mic $
 * @package		Translation Frontend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']		= 'Parcelforce 48';
$_['text_description']	= 'Parcelforce 48';
$_['text_weight']		= 'Gewicht';
$_['text_insurance']	= 'Versichert bis';
$_['text_time']			= 'Versand binnen 48 Stunden';