<?php
/**
 * @version		$Id: map.php 4102 2015-10-20 16:16:51Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Übersichtskarte';

$_['text_order']	= 'Aufträge';
$_['text_sale']		= 'Summe';