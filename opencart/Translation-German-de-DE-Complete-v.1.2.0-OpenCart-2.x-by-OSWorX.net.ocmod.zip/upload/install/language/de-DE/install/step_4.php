<?php
/**
 * @version		$Id: step_4.php 4344 2016-06-01 10:19:06Z mic $
 * @package		Translation Deutsch Installation
 * @author		mic - http://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']					= 'Installation abgeschlossen';

// Text
$_['text_step_4']					= 'Los geht\'s mit Verkaufen ...';
$_['text_catalog']					= 'Zum Shop';
$_['text_admin']					= 'Zur Verwaltung';
$_['text_loading']					= 'Lade Module ..';
$_['text_extension']				= 'Erweiterungsstore besuchen';
$_['text_mail']						= 'Newsletter abonnieren';
$_['text_mail_description']			= 'Informationen über Updates und Ereignisse';

$_['text_openbay']					= 'OpenBay Pro gibt Händlern die Möglichkeit den eigenen Shop mit anderen wie z.B. eBay und Amazon zu verlinken. Aufträge importieren, Artikel listen, Versandinfos .. alles direkt aus dem Shop heraus ..';
$_['text_maxmind']					= 'MaxMind ist ein Service um Risiken bei Transaktionen zu minimieren';
$_['text_more_info']				= 'Weitere Infos';
$_['text_facebook']					= 'Like us auf Facebook';
$_['text_facebook_description']		= 'Wie gefällt OpenCart?';
$_['text_facebook_visit']			= 'Facebookseite besuchen';
$_['text_forum']					= 'Foren';
$_['text_forum_description']		= 'Hilfe von anderen Benutzern erhalten';
$_['text_forum_visit']				= 'Foren besuchen';
$_['text_commercial']				= 'Kommerzielle Hilfe';
$_['text_commercial_description']	= 'Entwicklerdienste von Partnern';
$_['text_commercial_visit']			= 'Partnerseite besuchen';
$_['text_view']						= 'Details anzeigen';
$_['text_download']					= 'Download';
$_['text_downloads']				= 'Downloads';

// Button
$_['button_mail']					= 'Hier anmelden';
$_['button_setup']					= 'Jetzt installieren';

// Error
$_['error_warning']					= '<div style="width: 90%; margin-left: 30px; color: #000000;"><b>Abschließende Hinweise</b><ul class="fa-ul"><li><i class="fa-li fa fa-check-square"></i>Nicht vergessen den <b>Installationsordner</b> entweder zu löschen oder umzubenennen (dann auch Rechte auf 0644 setzen)!</li><li><i class="fa-li fa fa-check-square"></i>Wird nachträglich ein SSL-Zertifikat installiert, nicht vergessen die 2 <b>config.php</b> anzupassen (HTTPS_SERVER) sowie in den Shopeinstellungen zu aktivieren</li><li><i class="fa-li fa fa-check-square"></i>Für SEO-URLs muss die <b>.htaccess.txt in .htaccess</b> umbenannt werden</li></ul><i class="fa fa-cog fa-spin fa-2x fa-fw"></i>&nbsp;&nbsp;Individuelle Hilfe, Programmierung, spezielles OpenCart-Hosting, Erweiterungen sowie Anleitungen auf <a href="https://opencart360.com" target="_blank">Opencart360.com</a></div>';