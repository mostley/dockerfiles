<?php
/**
 * @version		$Id: footer.php 4344 2016-06-01 10:19:06Z mic $
 * @package		Translation Deutsch Installation
 * @author		mic - http://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_project']			= 'Projektseite';
$_['text_documentation']	= 'Dokumentation';
$_['text_support']			= 'Supportforen</a> |<a href="https://osworx.net" target="_blank">OSWorX';
$_['text_footer']			= 'Copyright © 2014 OpenCart - All rights reserved<br />Dt. Übersetzung ' . date('Y') . ' von <a href="https://osworx.net" target="_blank">OSWorX</a>';