<?php
/**
 * @version		$Id: column_left.php 4344 2016-06-01 10:19:06Z mic $
 * @package		Translation Deutsch Installation
 * @author		mic - http://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_license']			= 'Lizenz';
$_['text_installation']		= 'Servereinstellungen';
$_['text_configuration']	= 'Konfiguration';
$_['text_upgrade']			= 'Upgrade';
$_['text_finished']			= 'Fertig';
$_['text_language']			= 'Sprache';